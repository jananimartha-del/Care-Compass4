import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  calculateHaversineDistance,
  computeTriageScore,
  estimateTravelMinutes
} from '../src/utils/haversine.js';
import { clampBedCount, sanitizeText } from '../src/utils/security.js';
import { INITIAL_HOSPITALS } from '../src/data/mockHospitals.js';
import { createApp } from '../server/index.js';

test('Haversine distance and travel ETA handle edge cases accurately', () => {
  assert.equal(calculateHaversineDistance(17.4326, 78.4071, 17.4326, 78.4071), 0);
  assert.equal(calculateHaversineDistance(Number.NaN, 78.4071, 17.4326, 78.4071), 0);

  const dist = calculateHaversineDistance(17.4326, 78.4071, 17.4435, 78.3665);
  assert.ok(dist > 3.5 && dist < 5.5, `Expected ~4.5 km, got ${dist}`);
  assert.ok(estimateTravelMinutes(dist) >= 3);
});

test('computeTriageScore penalizes zero-availability wards and rewards proximity + readiness', () => {
  const fullHospital = INITIAL_HOSPITALS.find((h) => h.id === 'hosp-06');
  const openHospital = INITIAL_HOSPITALS.find((h) => h.id === 'hosp-01');
  assert.equal(computeTriageScore(fullHospital, 2.0, 'icu'), 0);
  assert.ok(computeTriageScore(openHospital, 1.9, 'icu') > 65);
});

test('clampBedCount and sanitizeText enforce bounds and strip XSS vectors', () => {
  assert.equal(clampBedCount(-10, 25), 0);
  assert.equal(clampBedCount(100, 25), 25);
  assert.equal(clampBedCount(14, 25), 14);

  const payload = '<img src=x onerror=alert(1)>javascript:alert(2) Trauma';
  const clean = sanitizeText(payload);
  assert.ok(!clean.includes('<') && !clean.includes('>'));
  assert.ok(!/javascript:/i.test(clean));
  assert.ok(!/onerror=/i.test(clean));
});

test('Express REST API supports persistence, auth, validation, and audit logs', async () => {
  const tmpFile = path.join(os.tmpdir(), `carecompass-test-${Date.now()}.json`);
  const app = createApp({ persistPath: tmpFile });
  const server = app.listen(0);
  const { port } = server.address();
  const baseUrl = `http://127.0.0.1:${port}`;

  try {
    const res = await fetch(`${baseUrl}/api/hospitals?lat=17.4326&lng=78.4071`);
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.equal(data.count, 6);
    assert.ok(typeof data.hospitals[0].distanceKm === 'number');

    const badWardRes = await fetch(`${baseUrl}/api/hospitals/hosp-01/beds`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'x-dispatch-token': 'ADMIN2026'
      },
      body: JSON.stringify({ ward: 'unknown_ward', available: 5 })
    });
    assert.equal(badWardRes.status, 400);

    const okPatch = await fetch(`${baseUrl}/api/hospitals/hosp-01/beds`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'x-dispatch-token': 'ADMIN2026'
      },
      body: JSON.stringify({ ward: 'icu', available: 10, note: 'Admitted trauma case' })
    });
    assert.equal(okPatch.status, 200);
    assert.equal(fs.existsSync(tmpFile), true);

    const auditRes = await fetch(`${baseUrl}/api/audit-logs`);
    const auditData = await auditRes.json();
    assert.equal(auditData.count, 1);
  } finally {
    server.close();
    if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile);
  }
});
