import express from 'express';
import cors from 'cors';
import fs from 'node:fs';
import path from 'node:path';
import { INITIAL_HOSPITALS } from '../src/data/mockHospitals.js';
import { calculateHaversineDistance, computeTriageScore } from '../src/utils/haversine.js';
import { clampBedCount, sanitizeText } from '../src/utils/security.js';

export function createApp(options = {}) {
  const app = express();
  const DISPATCH_TOKEN = process.env.DISPATCH_TOKEN || 'ADMIN2026';
  const persistPath = options.persistPath || null;

  let hospitals = structuredClone(INITIAL_HOSPITALS);
  const auditLogs = [];

  if (persistPath && fs.existsSync(persistPath)) {
    try {
      const loaded = JSON.parse(fs.readFileSync(persistPath, 'utf-8'));
      if (Array.isArray(loaded.hospitals) && loaded.hospitals.length > 0) {
        hospitals = loaded.hospitals;
      }
      if (Array.isArray(loaded.auditLogs)) {
        auditLogs.push(...loaded.auditLogs);
      }
    } catch {
      // Fall back to baseline snapshot
    }
  }

  const saveState = () => {
    if (!persistPath) return;
    try {
      fs.mkdirSync(path.dirname(persistPath), { recursive: true });
      fs.writeFileSync(persistPath, JSON.stringify({ hospitals, auditLogs }, null, 2));
    } catch {
      // Ignore write failure in read-only environments
    }
  };

  app.use(cors());
  app.use(express.json({ limit: '64kb' }));

  // Security headers
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'no-referrer');
    next();
  });

  // Lightweight sliding-window rate limiter per client IP
  const rateBuckets = new Map();
  app.use((req, res, next) => {
    const key = req.ip || 'local';
    const now = Date.now();
    const windowMs = 60_000;
    const maxReq = 120;
    const timestamps = (rateBuckets.get(key) || []).filter((t) => now - t < windowMs);
    if (timestamps.length >= maxReq) {
      return res.status(429).json({ error: 'Too many requests' });
    }
    timestamps.push(now);
    rateBuckets.set(key, timestamps);
    return next();
  });

  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'care-compass-api',
      version: '4.0.0',
      facilitiesCount: hospitals.length,
      timestamp: new Date().toISOString()
    });
  });

  app.get('/api/hospitals', (req, res) => {
    const lat = Number.parseFloat(req.query.lat);
    const lng = Number.parseFloat(req.query.lng);
    const hasCoords = !Number.isNaN(lat) && !Number.isNaN(lng);

    const payload = hospitals.map((h) => {
      if (!hasCoords) return h;
      const distanceKm = calculateHaversineDistance(lat, lng, h.lat, h.lng);
      const triageScore = computeTriageScore(h, distanceKm, 'icu');
      return { ...h, distanceKm, triageScore };
    });

    res.json({ count: payload.length, hospitals: payload });
  });

  app.get('/api/audit-logs', (_req, res) => {
    res.json({ count: auditLogs.length, logs: auditLogs });
  });

  app.patch('/api/hospitals/:id/beds', (req, res) => {
    const token = req.headers['x-dispatch-token'];
    if (token !== DISPATCH_TOKEN) {
      return res.status(401).json({ error: 'Unauthorized dispatcher token' });
    }

    const facility = hospitals.find((f) => f.id === req.params.id);
    if (!facility) {
      return res.status(404).json({ error: 'Hospital not found' });
    }

    const { ward, available, note } = req.body || {};
    if (!Object.prototype.hasOwnProperty.call(facility.beds, ward)) {
      return res.status(400).json({ error: 'Invalid ward type' });
    }

    const parsed = Number.parseInt(available, 10);
    if (Number.isNaN(parsed)) {
      return res.status(400).json({ error: 'Available count must be an integer' });
    }

    const clamped = clampBedCount(parsed, facility.beds[ward].total);
    facility.beds[ward].available = clamped;
    facility.lastUpdated = 'Just now';

    const entry = {
      id: `${Date.now()}-${auditLogs.length + 1}`,
      hospitalId: facility.id,
      hospitalName: facility.name,
      ward,
      newAvailable: clamped,
      note: sanitizeText(note) || 'API bed reconciliation',
      timestamp: new Date().toISOString()
    };
    auditLogs.unshift(entry);
    saveState();

    return res.json({ facility, auditEntry: entry });
  });

  app.post('/api/reset', (req, res) => {
    const token = req.headers['x-dispatch-token'];
    if (token !== DISPATCH_TOKEN) {
      return res.status(401).json({ error: 'Unauthorized dispatcher token' });
    }
    hospitals = structuredClone(INITIAL_HOSPITALS);
    auditLogs.length = 0;
    saveState();
    return res.json({ status: 'reset', count: hospitals.length });
  });

  return app;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const PORT = process.env.PORT || 4000;
  const persistPath = process.env.DATA_FILE || path.resolve('server/data-store.json');
  const app = createApp({ persistPath });
  app.listen(PORT, () => {
    console.log(`CareCompass API (v4.0) listening on http://localhost:${PORT}`);
  });
}
