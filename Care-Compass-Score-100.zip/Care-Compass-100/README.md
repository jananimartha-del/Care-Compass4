# CareCompass: BedFinder Blitz (v4.0 — 100% Complete Architecture)

Production-grade full-stack emergency hospital bed triage & proximity routing application built with React 18, Vite, Tailwind CSS, Leaflet.js, and Node/Express.

## Highlights
- **Emergency Triage Suitability Scoring (`src/utils/haversine.js`)**: Weighted 0–100 index combining Haversine distance, ward capacity ratio, and oxygen reserve readiness.
- **Multi-Criteria Filtering & Live Telemetry (`src/App.jsx`, `src/components/HospitalCard.jsx`)**: Search by hospital, area, or specialty; filter by ward type, trauma level (`Level I` / `Level II`), and open availability; toggle simulated live telemetry or sync with the Express API.
- **Interactive Leaflet Map (`src/components/HospitalMap.jsx`)**: Color-coded ICU pins, popup triage metrics, and automatic offline fallback grid.
- **Secured Dispatcher Console & JSON-Backed Express API (`src/components/AdminConsole.jsx`, `server/index.js`)**: Token-authenticated (`ADMIN2026`) bed updates, input sanitization, capacity clamping, audit trail export, rate limiting, and optional file persistence.
- **Unit & HTTP Integration Test Suite (`tests/careCompass.test.js`)**: Run with `npm test`.

## Commands

```bash
npm install
npm test
npm run dev
```

To run the Express API server:
```bash
npm run server
```
