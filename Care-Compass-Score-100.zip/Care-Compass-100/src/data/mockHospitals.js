export const DEFAULT_USER_LOCATION = {
  lat: 17.4326,
  lng: 78.4071,
  label: 'Jubilee Hills, Hyderabad'
};

export const INITIAL_HOSPITALS = [
  {
    id: 'hosp-01',
    name: 'Apollo Health City',
    tier: 'Tier-1 Multispecialty',
    address: 'Road No. 72, Film Nagar, Jubilee Hills, Hyderabad',
    phone: '+91 40 2360 7777',
    lat: 17.4156,
    lng: 78.4126,
    traumaLevel: 'Level I Trauma',
    oxygenReservePct: 96,
    ventilatorsAvailable: 14,
    lastUpdated: 'Just now',
    specialties: ['Cardiology', 'Neurology', 'Trauma', 'Oncology'],
    beds: {
      icu: { available: 8, total: 32 },
      general: { available: 42, total: 180 },
      nicu: { available: 5, total: 18 },
      isolation: { available: 6, total: 20 }
    }
  },
  {
    id: 'hosp-02',
    name: 'Yashoda Hospitals',
    tier: 'Tier-1 Multispecialty',
    address: 'Raj Bhavan Rd, Somajiguda, Hyderabad',
    phone: '+91 40 4567 4567',
    lat: 17.4258,
    lng: 78.4573,
    traumaLevel: 'Level I Trauma',
    oxygenReservePct: 91,
    ventilatorsAvailable: 9,
    lastUpdated: '2 mins ago',
    specialties: ['Pulmonology', 'Cardiology', 'Critical Care'],
    beds: {
      icu: { available: 4, total: 28 },
      general: { available: 29, total: 150 },
      nicu: { available: 3, total: 14 },
      isolation: { available: 4, total: 16 }
    }
  },
  {
    id: 'hosp-03',
    name: 'AIG Hospitals',
    tier: 'Quaternary Care',
    address: 'Mindspace Rd, Gachibowli, Hyderabad',
    phone: '+91 40 4244 4222',
    lat: 17.4435,
    lng: 78.3665,
    traumaLevel: 'Level I Trauma',
    oxygenReservePct: 98,
    ventilatorsAvailable: 19,
    lastUpdated: '1 min ago',
    specialties: ['Gastroenterology', 'Transplant', 'Critical Care', 'Neurology'],
    beds: {
      icu: { available: 11, total: 40 },
      general: { available: 54, total: 220 },
      nicu: { available: 6, total: 20 },
      isolation: { available: 9, total: 24 }
    }
  },
  {
    id: 'hosp-04',
    name: 'KIMS Hospitals',
    tier: 'Tier-1 Multispecialty',
    address: '1-8-31/1, Minister Rd, Secunderabad',
    phone: '+91 40 4488 5000',
    lat: 17.4366,
    lng: 78.4851,
    traumaLevel: 'Level I Trauma',
    oxygenReservePct: 88,
    ventilatorsAvailable: 7,
    lastUpdated: '4 mins ago',
    specialties: ['Cardiology', 'Orthopedics', 'Trauma', 'Pediatrics'],
    beds: {
      icu: { available: 2, total: 30 },
      general: { available: 18, total: 165 },
      nicu: { available: 2, total: 15 },
      isolation: { available: 3, total: 15 }
    }
  },
  {
    id: 'hosp-05',
    name: 'Continental Hospitals',
    tier: 'Tier-1 Multispecialty',
    address: 'Plot No. 3, Road No. 2, Financial District, Nanakramguda',
    phone: '+91 40 6700 0000',
    lat: 17.4178,
    lng: 78.3396,
    traumaLevel: 'Level II Trauma',
    oxygenReservePct: 94,
    ventilatorsAvailable: 12,
    lastUpdated: '3 mins ago',
    specialties: ['Oncology', 'Neurology', 'Emergency Medicine'],
    beds: {
      icu: { available: 7, total: 26 },
      general: { available: 36, total: 140 },
      nicu: { available: 4, total: 12 },
      isolation: { available: 5, total: 14 }
    }
  },
  {
    id: 'hosp-06',
    name: 'CARE Hospitals',
    tier: 'Specialty Cardiac & Trauma',
    address: 'Road No. 1, Banjara Hills, Hyderabad',
    phone: '+91 40 6165 6565',
    lat: 17.4121,
    lng: 78.4488,
    traumaLevel: 'Level II Trauma',
    oxygenReservePct: 84,
    ventilatorsAvailable: 5,
    lastUpdated: '5 mins ago',
    specialties: ['Cardiology', 'Nephrology', 'Critical Care'],
    beds: {
      icu: { available: 0, total: 22 },
      general: { available: 12, total: 110 },
      nicu: { available: 1, total: 10 },
      isolation: { available: 2, total: 12 }
    }
  }
];
