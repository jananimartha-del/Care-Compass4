/**
 * Computes great-circle distance (km) between two geographic coordinates
 * using the spherical Haversine formula with strict coordinate validation.
 */
export function calculateHaversineDistance(lat1, lon1, lat2, lon2) {
  const coords = [lat1, lon1, lat2, lon2];
  if (coords.some((n) => typeof n !== 'number' || Number.isNaN(n) || !Number.isFinite(n))) {
    return 0;
  }

  const toRad = (deg) => (deg * Math.PI) / 180;
  const earthRadiusKm = 6371;

  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Number((earthRadiusKm * c).toFixed(2));
}

/**
 * Estimates urban emergency transit ETA in minutes from Haversine distance (km).
 */
export function estimateTravelMinutes(distanceKm) {
  const safeDist = Math.max(0, Number(distanceKm) || 0);
  const avgUrbanSpeedKmh = 32;
  return Math.max(3, Math.round((safeDist / avgUrbanSpeedKmh) * 60 + 2));
}

/**
 * Computes a 0-100 Emergency Triage Suitability Score combining:
 * - Proximity decay (55%)
 * - Target ward availability ratio (30%)
 * - Facility oxygen reserve readiness (15%)
 */
export function computeTriageScore(hospital, distanceKm, targetWard = 'icu') {
  const wardKey = hospital?.beds?.[targetWard] ? targetWard : 'icu';
  const ward = hospital?.beds?.[wardKey];
  if (!ward || ward.available <= 0) return 0;

  const availabilityRatio = Math.min(1, Math.max(0, ward.available / Math.max(1, ward.total)));
  const proximityFactor = Math.max(0, 1 - Math.min(Math.max(0, distanceKm), 25) / 25);
  const oxygenFactor = Math.min(1, Math.max(0, (hospital.oxygenReservePct ?? 85) / 100));

  return Math.round(proximityFactor * 55 + availabilityRatio * 30 + oxygenFactor * 15);
}
